def linear_search_product(products, target_product):
    indices = []
    for i, product in enumerate(products):
        if product == target_product:
            indices.append(i)
    return indices

def main():
    # Example usage
    products = ["apple", "banana", "apple", "orange", "apple"]
    target = "apple"

    result = linear_search_product(products, target)

    if result:
        print(f"The product '{target}' is found at indices: {result}")
    else:
        print(f"The product '{target}' is not found.")

if __name__ == "__main__":
    main()
